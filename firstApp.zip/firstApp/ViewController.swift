
import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var playingScreen: UIView!
    @IBOutlet weak var rockButton: UIButton!
    @IBOutlet weak var paperButton: UIButton!
    @IBOutlet weak var scissorButton: UIButton!
    @IBOutlet weak var chosenButton: UIImageView!
    @IBOutlet weak var myScore: UILabel!
    @IBOutlet weak var cpuScore: UILabel!
    @IBOutlet weak var centreStack: UIStackView!
    @IBOutlet weak var buttonStack: UIStackView!
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var cpuChose: UIImageView!
    @IBOutlet weak var roundLabel: UILabel!
    @IBOutlet weak var whoScored: UILabel!
    @IBOutlet weak var statsButton: UIButton!
    @IBOutlet weak var manualButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var mainMenuButton: UIButton!
    @IBOutlet weak var mainMenuImage: UIImageView!
    @IBOutlet weak var whoWonLabel: UILabel!
    @IBOutlet weak var roundSelector: UIStepper!
    @IBOutlet weak var roundSelectLabel: UILabel!
    @IBOutlet weak var anotherMainMenuButton: UIButton!
    @IBOutlet weak var rulesScreen: UIImageView!
    
    @IBOutlet weak var centreConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var timerConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var playConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var manualConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var statsConstraint: NSLayoutConstraint!
    
    var myPoint = 0
    var cpuPoint = 0
    var bestOf = 3
    var round = 0
    
    var time = 3
    var timer = Timer()
    
    var centre: CGFloat = 0
    var bottom: CGFloat = 0
    var t: CGFloat = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myPoint = 0
        cpuPoint = 0
        round = 0
        bottom = bottomConstraint.constant
        centreConstraint.constant -= view.bounds.width
        bottomConstraint.constant += 250
        timerConstraint.constant -= view.bounds.width
        
        playConstraint.constant += view.bounds.width
        statsConstraint.constant += view.bounds.width
        manualConstraint.constant += view.bounds.width
        
        mainMenuAnimation()
    }
    
    func initialSetup() {
        playButton.isHidden = true
        statsButton.isHidden = true
        manualButton.isHidden = true
        mainMenuImage.isHidden = true
        nextButton.isHidden = true
        
        whoScored.isHidden = true
        if round < bestOf {
            round = round + 1
            roundLabel.text = String(round)
            timerAnimation()
            buttonsAnimation(5, 1)
        }
        else {
            whoWonLabel.isHidden = false
            if myPoint > cpuPoint {
                whoWonLabel.text = String("You Win!")
            }
            else if cpuPoint > myPoint {
                whoWonLabel.text = String("You Lose!")
            }
            else {
                whoWonLabel.text = String("Tie!")
            }
            
            nextButton.setImage(UIImage(named: "restart-icon.png"), for: UIControlState.normal)
            nextButton.isHidden = false
        }
    }
    
    @IBAction func roundPressed(_ sender: UIStepper) {
        roundSelectLabel.text = String("Rounds: \(Int(sender.value))")
        bestOf = Int(sender.value)
    }
    
    @IBAction func playPressed(_ sender: UIButton) {
        print("pressed")
        playingScreen.isHidden = false
        initialSetup()
    }
    
    @IBAction func manualPressed(_ sender: Any) {
        rulesScreen.isHidden = false
        anotherMainMenuButton.isHidden = false
    }
    
    @IBAction func anotherBackButtonPressed(_ sender: Any) {
        rulesScreen.isHidden = true
        anotherMainMenuButton.isHidden = true
    }
    
    @IBAction func mainMenuPressed(_ sender: Any) {
        mainMenu()
    }
    
    @IBAction func nextPressed(_ sender: Any) {
        if nextButton.currentImage?.isEqual(UIImage(named: "restart-icon.png")) == true {
            round = 0
            myPoint = 0
            cpuPoint = 0
            myScore.text = String(myPoint)
            cpuScore.text = String(cpuPoint)
            whoWonLabel.isHidden = true
            nextButton.setImage(UIImage(named: "NextButton-1.png"), for: UIControlState.normal)
            initialSetup()
        }
        else {
           initialSetup()
        }
    }
    
    @objc func action() {
        if time == 0 {
            timerLabel.text = "GO!"
            timer.invalidate()
            time = 3
        }
        else{
            timerLabel.text = String(time)
            time = time - 1
        }
    }
    
    @IBAction func rockPressed(_ sender: UIButton) {
        buttonsAnimation(2.5, 0)
        chosenButton.image = UIImage(named: "Rock.jpeg")
        var cpu = arc4random_uniform(3) + 1
        whoScored.isHidden = false
        if cpu == 1 {
            cpuChose.image = UIImage(named: "Rock.jpeg")
            whoScored.text = String("Tie")
        }
        else if cpu == 2 {
            cpuChose.image = UIImage(named: "Paper.jpeg")
            cpuPoint = cpuPoint + 1
            whoScored.text = String("CPU Scored")
        }
        else {
            cpuChose.image = UIImage(named: "Scissor.jpeg")
            myPoint = myPoint + 1
            whoScored.text = String("You Scored")
        }
        centreAnimation()
        myScore.text = String(myPoint)
        cpuScore.text = String(cpuPoint)
        nextButton.isHidden = false
    }
    
    @IBAction func paperPressed(_ sender: UIButton) {
        buttonsAnimation(2.5, 0)
        chosenButton.image = UIImage(named: "Paper.jpeg")
        var cpu = arc4random_uniform(3) + 1
        whoScored.isHidden = false
        if cpu == 1 {
            cpuChose.image = UIImage(named: "Rock.jpeg")
            myPoint = myPoint + 1
            whoScored.text = String("You Scored")
        }
        else if cpu == 2 {
            cpuChose.image = UIImage(named: "Paper.jpeg")
            whoScored.text = String("Tie")
        }
        else {
            cpuChose.image = UIImage(named: "Scissor.jpeg")
            cpuPoint = cpuPoint + 1
            whoScored.text = String("CPU Scored")
        }
        centreAnimation()
        myScore.text = String(myPoint)
        cpuScore.text = String(cpuPoint)
        nextButton.isHidden = false
    }
    
    @IBAction func scissorPressed(_ sender: UIButton) {
        buttonsAnimation(2.5, 0)
        chosenButton.image = UIImage(named: "Scissor.jpeg")
        var cpu = arc4random_uniform(3) + 1
        whoScored.isHidden = false
        if cpu == 1 {
            cpuChose.image = UIImage(named: "Rock.jpeg")
            cpuPoint = cpuPoint + 1
            whoScored.text = String("CPU Scored")
        }
        else if cpu == 2 {
            cpuChose.image = UIImage(named: "Paper.jpeg")
            myPoint = myPoint + 1
            whoScored.text = String("You Scored")
        }
        else {
            cpuChose.image = UIImage(named: "Scissor.jpeg")
            whoScored.text = String("Tie")
        }
        centreAnimation()
        myScore.text = String(myPoint)
        cpuScore.text = String(cpuPoint)
        nextButton.isHidden = false
    }
    
    func centreAnimation() {
        UIView.animate(withDuration: 0.5, delay: 0, options: .transitionCurlUp, animations: {
            self.centreConstraint.constant += self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        UIView.animate(withDuration: 0.5, delay: 2.5, options: .transitionCurlDown, animations: {
            self.centreConstraint.constant -= self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
    }
    
    func buttonsAnimation(_ d: Double, _ inOrOut: Int) {
        if inOrOut == 1 {
            UIView.animate(withDuration: 0.5, delay: 5, options: .curveEaseIn, animations: {
                self.bottomConstraint.constant -= 250
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
        else {
            UIView.animate(withDuration: 1, delay: d, options: .curveEaseOut, animations: {
                self.bottomConstraint.constant += 250
                self.view.layoutIfNeeded()
            }, completion: nil)
        }
        
    }
    
    func timerAnimation() {
        UIView.animate(withDuration: 0.5, delay: 1, options: .curveEaseIn, animations: {
            self.timerConstraint.constant += self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.action), userInfo: nil, repeats: true)
        
        UIView.animate(withDuration: 0.5, delay: 5, options: .curveEaseOut, animations: {
            self.timerConstraint.constant -= self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    func mainMenuAnimation() {
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseIn, animations: {
            self.playConstraint.constant -= self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.5, options: .curveEaseIn, animations: {
            self.statsConstraint.constant -= self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 1, options: .curveEaseIn, animations: {
            self.manualConstraint.constant -= self.view.bounds.width
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    func setOriginalConstraintSetup() {
        if self.bottomConstraint.constant == (self.bottom + 250) {
            //Do nothing
        }
        else{
            self.bottomConstraint.constant += 250
        }
    }
    
    func mainMenu() {
        playingScreen.isHidden = true
        playButton.isHidden = false
        statsButton.isHidden = false
        manualButton.isHidden = false
        whoWonLabel.isHidden = true
        nextButton.setImage(UIImage(named: "NextButton-1.png"), for: UIControlState.normal)
        mainMenuImage.isHidden = false
        timer.invalidate()
        time = 3
        myPoint = 0
        cpuPoint = 0
        round = 0
        myScore.text = String(myPoint)
        cpuScore.text = String(cpuPoint)
        setOriginalConstraintSetup()
        return
    }

}
